#
# Filename: DADA2_R_pipeline_EJ_A3.R
#
# Purpose: ASV inference in StrainID or V1V9 samples using DADA2 in R.
#		For local windows cmd execution with Rscript, interactive cluster session with Rscript, or cluster batch submission with Rscript
#
# Created: 28-Jul-2020
#
# Revision: A3
#
# History:
#	28-Aug-2020 E. Jackson
#		Addeed a check for whether the no primer (nop) or filtered (filt) fastqs already exist in the specified location.
#		Added outputs with chimeras removed using removeBimeraDenovo.
#	19-Aug-2020 E. Jackson
#		Added check for OS type (windows vs unix) to use / vs \ in filepaths appropriately
#		Reorganized and changed all package installations to be handled by Bioconductor, added dependencies explicitly
#	14-Aug-2020 E. Jackson
#		Changed run parameters to be supplied as command line arguments
#		Changed package installation to create new directory, support operation on clusters

start_time <- Sys.time()

#get package directory from command line arguments, make directory if not already there
cmdargs <- commandArgs(trailingOnly = TRUE)
R_pkg_dir <- cmdargs[1:2]
if (length(cmdargs) != 14) {
	stop("incorrect number of arguments")
}
if (R_pkg_dir[1] != "--pkgdir") {
	stop("first supplied option must be --pkgdir <path to writeable R pkg directory>")
}
.libPaths(new=R_pkg_dir[2])
dir.create(R_pkg_dir[2], showWarnings = TRUE, recursive = FALSE, mode = "0777")

biocm_pkg_list <- c("Biostrings","Rhtslib","Rsamtools","GenomicAlignments","hwriter","ShortRead","RcppParallel","plyr","reshape2","dada2","Rhdf5lib","pixmap","rhdf5","sp","ade4","permute","vegan","multtest","igraph","iterators","foreach","biomformat","ape","phyloseq","ggplot2","gridExtra","RColorBrewer","docopt")

#install R packages if they aren't already installed
if (!require("BiocManager",lib.loc=R_pkg_dir[2],quietly=TRUE)) {
	install.packages("BiocManager",lib=R_pkg_dir[2],repos="https://cloud.r-project.org",quiet=TRUE)
}
for (i in which(!(biocm_pkg_list %in% rownames(installed.packages(lib.loc=R_pkg_dir[2]))))) {
	BiocManager::install(biocm_pkg_list[i],lib=R_pkg_dir[2],quiet=TRUE)
}

#Loads all of the packages needed to run script
for (i in 1:length(biocm_pkg_list)) {
	library(biocm_pkg_list[i],lib.loc=R_pkg_dir[2],quietly=TRUE,character.only=TRUE)
}

"Usage:
	script.R (--pkgdir PKGDIR) (-n RUNNAME) (-i FASTQDIR) (-s SEQTYPE) (-a OMEGAA) (-c OMEGAC) (-p POOLMODE)

Options:
	--pkgdir PKGDIR	directory for packages
	-n RUNNAME	appends to filenames
	-i FASTQDIR	directory with fastqs
	-s SEQTYPE	type of amplicon
	-a OMEGAA	dada2 omega_A setting
	-c OMEGAC	dada2 omega_C setting
	-p POOLMODE	dada2 pooling mode" -> doc

opts <- docopt(doc,help=TRUE)
run_name <- opts$n
setwd(opts$i)
if (.Platform$OS.type == "windows") {
	path <- gsub("/", "\\\\", getwd())
} else if (.Platform$OS.type == "unix") {
	path <- getwd()
}
seq_type <- opts$s
om_A <- opts$a
om_C <- opts$c
pool_mode <- opts$p

#check user supplied arguments are correct format etc
if (!(dir.exists(opts$i))) {
	stop("Directory does not exist")
}
if(grepl(pattern="\\s", run_name, perl=TRUE)) {
	stop("Avoid using spaces in the run name")
}
if ((seq_type != "StrainID")&(seq_type != "V1V9")) {
	stop("Only provide StrainID or V1V9")
}
if(grepl(pattern="^1e-\\d+$", om_A, perl=TRUE)) {
	om_A <- as.numeric(om_A)
} else {
	stop("OMEGA_A must be in the form 1e-X where X is a number")
}
if(grepl(pattern="^1e-\\d+$", om_C, perl=TRUE)) {
	om_C <- as.numeric(om_C)
} else {
	stop("OMEGA_C must be in the form 1e-X where X is a number")
}
if ((pool_mode != TRUE)&(pool_mode != "pseudo")&(pool_mode != FALSE)) {
	stop("Pooling mode must be TRUE, pseudo, or FALSE")
}

#makes a list of all the .fastq files in the given directory
fn <- list.files(path, pattern=".fastq", full.names=TRUE)
#makes names out of the .fastq files that may or may not be descriptive of samples, used to label things
fn_names <- paste(gsub(".*sfinderOutput.", "", gsub(".fastq", "", basename(fn))))

#primer sequences used, fwd is the same for strainID or V1V9, rev is determined by user argument "StrainID" or "V1V9"
#length filtering parameters determined by user input as well, StrainID 1900-3000, V1V9 1300-1700
F27Degen <- "AGRRTTYGATYHTDGYTYAG"

if (seq_type == "V1V9") {
	revprimer <- "AAGTCGTAACAAGGTADCBSTA" #v9
	minfilt <- 1300
	maxfilt <- 1700
} else if (seq_type == "StrainID") {
	revprimer <- "AGTACYRHRARGGAANGR" #ext3
	minfilt <- 1900
	maxfilt <- 3000
}

rc <- dada2:::rc
theme_set(theme_bw())

#makes a list of filenames for primer trimmed .fastq files to be made
nop <- file.path(path, "noprimers", basename(fn))

#trims primers from input .fastq sequences and makes trimmed gzipped output .fastq files
#these are in the /noprimers directory
if (any(!(file.exists(nop)))) {
	primno <- 1
	primall <- matrix(nrow = 0, ncol = 2)
	while (primno <= length(fn)) {
		if (length(fn) - primno < 9) {
			prim <- removePrimers(fn[primno:length(fn)], nop[primno:length(fn)], primer.fwd=F27Degen, primer.rev=revprimer, orient=TRUE, verbose=TRUE, allow.indels=TRUE, max.mismatch = 2)
		} else {
			prim <- removePrimers(fn[primno:(primno + 9)], nop[primno:(primno + 9)], primer.fwd=F27Degen, primer.rev=revprimer, orient=TRUE, verbose=TRUE, allow.indels=TRUE, max.mismatch = 2)
		}
		primall <- rbind(primall, prim)
		primno <- primno + 10
	}
} else {
	print("Primer trimmed files already exist, counting sequences")
	primall <- matrix(nrow = length(fn), ncol = 2)
	for (i in 1:length(fn)) {
		primall[i,1] <- length(getSequences(fn[i]))
		primall[i,2] <- length(getSequences(nop[i]))
	}
	rownames(primall) <- basename(fn)
	colnames(primall) <- c("reads.in","reads.out")
}

lens.fn <- lapply(nop, function(x) nchar(getSequences(x)))
lens <- do.call(c, lens.fn)
#histogram of all trimmed read lengths
#hist(lens, 100)
write.csv(lens, file.path(path, paste(run_name, "_ReadLengthTrimmedTable.csv", sep="")))

#filters the primer trimmed .fastq sequences by quality and length
#filtered output .fastq files are in the /noprimers/filtered directory
filt <- file.path(path, "noprimers", "filtered", basename(fn))
if (any(!(file.exists(filt)))) {
	#this gets the directory and leaves behind the filename
	dir.create(dirname(filt[1]), showWarnings = TRUE, recursive = FALSE, mode = "0777")
	filecount <- length(fn)
	filesProcessed <- 1
	trackmat <- matrix(nrow=length(fn),ncol=2)
	while (filesProcessed <= filecount) {
		#may have to change length band if there are a lot of reads outside that
		#v1v9 1300-1700, strainid 1900-3000
		trackmat[filesProcessed,] <- fastqFilter(nop[filesProcessed], filt[filesProcessed], minQ=3, minLen=minfilt, maxLen=maxfilt, maxN=0, rm.phix=FALSE, maxEE=2, compress = TRUE, verbose=TRUE)
		filesProcessed = filesProcessed +1
	}
} else {
	print("Filtered files already exist, counting sequences")
	trackmat <- matrix(nrow = length(fn), ncol = 2)
	for (i in 1:length(fn)) {
		trackmat[i,1] <- primall[i,2]
		trackmat[i,2] <- length(getSequences(filt[i]))
	}
}
rownames(trackmat) <- basename(fn)
colnames(trackmat) <- c("reads.in","reads.out")
	
#makes list of read length sets from filtered samples
lens.filt <- lapply(filt, function(x) nchar(getSequences(x)))
lens.filt.c <- do.call(c, lens.filt)

print("saving\n")
save.image(file.path(path, paste(run_name, ".RData", sep="")))

print("dereplicating for error calc\n")
#dereplicates the trimmed/filtered .fastq sequences, leaving only unique sequences
drp <- derepFastq(filt, verbose=TRUE, qualityType = "FastqQuality")

print("calculating error profile\n")
#determines an error profile for the dereplicated sequences, required for dada2
err <- learnErrors(drp, BAND_SIZE=32, multithread=TRUE, errorEstimationFunction=dada2:::PacBioErrfun, qualityType = "FastqQuality")
#write.csv(err, file.path(path, paste(run_name, "_ErrorRateData.csv", sep="")))

print("running dada2\n")
#this is the dada2 step, which will denoise using the error profile, and then produce the ASV's
#with pool=TRUE, use readfinder python script to pull out reads of specific taxonomy, otherwise takes forever
#with pool=FALSE, no pooling happens
#with pool="pseudo", only uses lower OMEGA_A threshold for ASV's found in other samples, no pooling
if(pool_mode == "pseudo") {
	dd <- dada(drp, err=err, BAND_SIZE=32, multithread=TRUE, OMEGA_A = om_A, OMEGA_C = om_C, PSEUDO_PREVALENCE = 2, pool=pool_mode) 
} else if(pool_mode == TRUE) {
	dd <- dada(drp, err=err, BAND_SIZE=32, multithread=TRUE, OMEGA_A = om_A, OMEGA_C = om_C, PSEUDO_PREVALENCE = 2, pool=TRUE)
} else if(pool_mode == FALSE) {
	dd <- dada(drp, err=err, BAND_SIZE=32, multithread=TRUE, OMEGA_A = om_A, OMEGA_C = om_C, PSEUDO_PREVALENCE = 2, pool=FALSE) 
}
print("saving\n")
save.image(file.path(path, paste(run_name, ".RData", sep="")))

#make table of asvs ordered by abundance by default
#this will show how many times each ASV and its error corrected reads appear in each sample
st <- makeSequenceTable(dd)

#produce output files after chimera removal
st_nochi <- removeBimeraDenovo(st, method="pooled", minFoldParentOverAbundance = 3.5)
for (i in 1:length(rownames(st_nochi))) {
	rownames(st_nochi)[i] <- gsub(".*sfinderOutput.", "", gsub(".fastq", "", rownames(st_nochi)[i]))
}
write.csv(st_nochi, file.path(path, paste(run_name, "_sequence_table_nochiR.csv", sep="")))
jal_ready_out <- file(description = file.path(path, paste(run_name, "_ASVs_only_nochiR.fasta", sep="")), open = "w")
for (i in 1:length(colnames(st_nochi))) {
	writeLines(paste(">asv", i, nchar(colnames(st_nochi))[i], sep="_"), jal_ready_out)
	writeLines(colnames(st_nochi)[i], jal_ready_out)
}
close(jal_ready_out)
for (i in 1:length(colnames(st_nochi))) {
	colnames(st_nochi)[i] <- paste("asv", i, nchar(colnames(st_nochi)[i]), sep="_")
}
st_tot_heatmap_nochi <- t(st_nochi)
png(file.path(path, paste(run_name, "_asv_heatmap_nochiR.png", sep="")), width = 14, height = 8, units = "in", res = 450) #establishes parameters for the .png file, including a name
heatmap(st_tot_heatmap_nochi[], Colv = NA, main="ASV heatmap", distfun=function (y) dist(y,method = "canb"), col = hcl.colors(64, palette="Blue-Red 3"), scale = "column", cexRow = 0.5, cexCol = 0.5)
dev.off()
st_tot_heatmap_nochi_biom <- make_biom(st_tot_heatmap_nochi)
write_biom(st_tot_heatmap_nochi_biom, file.path(path, paste(run_name, "sequence_table_nochiR.biom", sep="_")))

#produce output files without chimera removal
#change fastq names to sample names in sequence table
for (i in 1:length(rownames(st))) {
	rownames(st)[i] <- gsub(".*sfinderOutput.", "", gsub(".fastq", "", rownames(st)[i]))
}

#write the contents of the sequence table to a csv
write.csv(st, file.path(path, paste(run_name, "_sequence_table.csv", sep="")))

#finds potential bimera (chimera of two read) sequences among the ASV's
bim <- isBimeraDenovo(st, minFoldParentOverAbundance=3.5, multithread=FALSE)

#print out asvs in fasta format
jal_ready_out <- file(description = file.path(path, paste(run_name, "_ASVs_only.fasta", sep="")), open = "w")
for (i in 1:length(colnames(st))) {
	writeLines(paste(">asv", i, nchar(colnames(st))[i], sep="_"), jal_ready_out)
	writeLines(colnames(st)[i], jal_ready_out)
}
close(jal_ready_out)

#change sequence table column names (actual sequences) to readable labels (asv_X_YYYY)
for (i in 1:length(colnames(st))) {
	colnames(st)[i] <- paste("asv", i, nchar(colnames(st)[i]), sep="_")
}

#transpose sequence table (rows <-> columns)
st_tot_heatmap <- t(st)

#make a heatmap and save it to a .png file
#for the dist function, manhattan, canberra, and binary work pretty well
#changing palette color count to like 16 or 8 might make differences more clear
png(file.path(path, paste(run_name, "_asv_heatmap.png", sep="")), width = 14, height = 8, units = "in", res = 450) #establishes parameters for the .png file, including a name
heatmap(st_tot_heatmap[], Colv = NA, main="ASV heatmap", distfun=function (y) dist(y,method = "canb"), col = hcl.colors(64, palette="Blue-Red 3"), scale = "column", cexRow = 0.5, cexCol = 0.5)
dev.off()

#make biom rich formatted feature table for qiime2 import
st_tot_heatmap_biom <- make_biom(st_tot_heatmap)
write_biom(st_tot_heatmap_biom, file.path(path, paste(run_name, "sequence_table.biom", sep="_")))

end_time <- Sys.time()
end_time - start_time

#save log of run parameters
run_log <- file(description = file.path(path, paste(run_name, "_run_log.txt", sep="")), open = "w")
writeLines(paste("run_name", run_name, sep="\t"), run_log)
writeLines(paste("directory", getwd(), sep="\t"), run_log)
writeLines(paste("seq_type", seq_type, sep="\t"), run_log)
writeLines(paste("OMEGA_A", om_A, sep="\t"), run_log)
writeLines(paste("OMEGA_C", om_C, sep="\t"), run_log)
writeLines(paste("pool_mode", pool_mode, sep="\t"), run_log)
writeLines(paste("start_time", start_time, sep="\t"), run_log)
writeLines(paste("end_time", end_time, sep="\t"), run_log)
close(run_log)

print("saving\n")
save.image(file.path(path, paste(run_name, ".RData", sep="")))