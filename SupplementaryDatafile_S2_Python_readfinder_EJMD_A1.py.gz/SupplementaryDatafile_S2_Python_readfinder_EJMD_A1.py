#
# Filename: readfinder_EJMD_A1.py
#
# Purpose: Extract reads of desired taxonomy from demultiplexed fastq files, for input into dada2 pipeline
#
# Created: 11-Mar-2020
#
# Revision: A1
#
# History:
#   14-Aug-2020 Eric Jackson
#       Changed user inputs to be passed from command line
#   13-Aug-2020 Mark Driscoll
#       Added handling for searches for "Bacteria;" and "unclassified"
#

print ('Program Start')

import sys, getopt, re, collections, os, fnmatch
from Bio.Seq import Seq

cmd_args = sys.argv[1:]

try:
    opts, args = getopt.getopt(cmd_args, "i:s:t:g:", ["indir=","taxsearch=","taxfile=","grpfile="])
except getopt.GetoptError as err:
    print(err)
    sys.exit()
for opt, arg in opts:
    if opt in ('-i', '--indir'):
        InputDirectory = arg
        print ("Input directory = " + arg)
    elif opt in ('-s', '--taxsearch'):
        if arg == "unclassified":
            TaxonToFind = "unclassified"
        elif arg == "Bacteria":
            TaxonToFind = "Bacteria;"
        else:
            TaxonToFind = ";" + arg + ";"
        OutputFileNameTaxon = arg
        print ("Search for taxon: " + TaxonToFind)
    elif opt in ('-t', '--taxfile'):
        TaxonFileName = arg
        print ("Taxonomy file path = " + arg)
    elif opt in ('-g', '--grpfile'):
        GroupsFile = arg
        print ("Groups file path = " + arg)

#Options to limit read extraction to a flat number of reads, deprecated at the moment
LimitReadSearch = 0#if LimitReads = 1, then program will only get the number after "ReadsToSearch"
LimitReadGet = 0
ReadsToSearch = 20000
ReadsToGet = 500

#for loop, searches specified directory for files ending in ".fastq", makes a list of them, runs the finder script once for each item in the list
fastq_list = []
listOfFiles = os.listdir(InputDirectory)
pattern = "*.fastq"
for entry in listOfFiles:
    if fnmatch.fnmatch(entry, pattern):
        print (entry)
        fastq_list.append(entry)

# SEPARATE READIDS ASSOCIATED WITH DESIRED TAXONOMY INTO A DICTIONARY KEYED TO SAMPLE NAMES
SampleNamesList = []
for i in fastq_list:
    SampleName = re.search('^sfinderOutput\.(.+)\.fastq', i)
    SampleNamesList.append(SampleName.group(1))
GroupsLines = open(GroupsFile)
GroupDictionary = {}
TaxonDictionary = {}
GroupsReadList = []
GroupsReadList = GroupsLines.readlines()
GroupsLines.close()
TaxonFile = open(TaxonFileName) #opens taxonomy file and names it 'TaxonFile'
TaxonReadList = []
TaxonReadList = TaxonFile.readlines() #reads into a list, with each element containing a line i.e. a read and taxonomy
TaxonFile.close()

#find the number of reads in the TaxonFileString of the TaxonFile. This is the total number of reads in the run that were assigned a taxonomy
AssignedReads = len(TaxonReadList)
#find the number of reads with the taxon of interest
if TaxonToFind == "unclassified":
    NumTaxReads = sum(";" not in s for s in TaxonReadList)
else:
    NumTaxReads = sum(TaxonToFind in s for s in TaxonReadList)
print ('# reads with taxon in the entire run = ', NumTaxReads)
#Get rid of the '\t' that confuses the dictionary searches
TaxonToFind = TaxonToFind.replace('\t', '')       
       
SampleTaxonomyIDDictionary = {}
for i in range(0,len(GroupsReadList)):
    GroupIDExtract = re.search('^(.+)\t(.+)\n', GroupsReadList[i])
    GroupDictionary[GroupIDExtract.group(1)] = GroupIDExtract.group(2)
for i in range(0,len(TaxonReadList)):
    TaxonIDExtract = re.search('^(.+)\t(.+)\n', TaxonReadList[i])
    TaxonDictionary[TaxonIDExtract.group(1)] = TaxonIDExtract.group(2)
SortedGroupDictionary = collections.OrderedDict(sorted(GroupDictionary.items()))
SortedTaxonDictionary = collections.OrderedDict(sorted(TaxonDictionary.items()))
for i in SortedTaxonDictionary:
    if TaxonToFind in SortedTaxonDictionary[i]:
        #if you are looking for 'unclassified', it is listed like ('m64015_200721_220845/100075360/ccs', 'unclassified'),
        #so we have to use the fact that all classified reads start with 'Bacteria;... eg., ('m64015_200721_220845/100075375/ccs','Bacteria;Firmicutes;Clostridia;Clostridiales;Ruminococcaceae;Ruminococcus;Ruminococcus_unclassified;Ruminococcus_unclassified'),
        #to exclude all the other instances of "_unclassifed;"
        UnclassifiedSearch = 'false'
        if TaxonToFind == 'unclassified':
            UnclassifiedSearch = 'true'
            if 'Bacteria;' in SortedTaxonDictionary[i]:
                #if 'bacteria' is there, it was classified, so skip it!
                pass
            #it was not classified, so collect it
            else:
                for j in SampleNamesList:
        #added to avoid conflicts of .tax and .group content
                    if i in dict.keys(SortedGroupDictionary):
                        if j == SortedGroupDictionary[i]:                
                            if j in SampleTaxonomyIDDictionary:
                                SampleTaxonomyIDDictionary[j].append(i)
                            else:
                                SampleTaxonomyIDDictionary[j] = [i]
        if UnclassifiedSearch == 'false':
            for j in SampleNamesList:
        #added to avoid conflicts of .tax and .group content
                    if i in dict.keys(SortedGroupDictionary):
                        if j == SortedGroupDictionary[i]:                
                            if j in SampleTaxonomyIDDictionary:
                                SampleTaxonomyIDDictionary[j].append(i)
                            else:
                                SampleTaxonomyIDDictionary[j] = [i]
#SampleTaxonomyIDDictionary contains the taxonomy-selected sample-demultiplexed readids

#For each entry in list of sample names, find corresponding fastq file name, open it, read each line into an element of a list
    #This list has one read every four elements i.e. 0 = readid 1 = sequence 2 = '+' 3 = quality, so going through line by line you know exactly what you'll encounter
FastqSequenceExtract = ""
FastqQualityExtract = ""

for i in SampleNamesList:
    for j in fastq_list:
        if i in j:
            ReadsWritten = 0
            FastqFile = open(InputDirectory + '/' + j)
            FastqReadList = FastqFile.readlines()
            FastqFile.close()
            OutputFileName = OutputFileNameTaxon + ('_reads_Found') + j
            NewPath = InputDirectory + '/' + OutputFileNameTaxon + '/' + OutputFileName
#make the directory for the new fastq files
            os.makedirs(os.path.dirname(NewPath), exist_ok=True)
#open a file to write the reads into once you find the appropriate fastq file
            with open(NewPath, 'a') as f:
                for k in range(1,len(FastqReadList) // 4):
#extract the readid string from the line, minus the @ so it can be matched to the values for the dictionary key corresponding to the sample
                    FastqIDExtract = re.search('^@(.+)\n', FastqReadList[k * 4 - 4])
                    
#attempt to match the readid to any value for the sample's key in the dictionary
                    if i in dict.keys(SampleTaxonomyIDDictionary):
                        if FastqIDExtract.group(1).strip() in SampleTaxonomyIDDictionary[i]:
                            FastqSequenceExtract = FastqReadList[k * 4 - 3].strip('\n')
                            FastqQualityExtract = FastqReadList[k * 4 - 1].strip('\n')                   
###test for reversed reads, same way as original script
                            FindRevV4 = FastqSequenceExtract.find('TTAGATACCCTGGTAGTC')#truncated V4 reverse primer in Forward direction
                            if FindRevV4 != -1:#Found it!
                                pass
                            else:
                                #look for an alternative if it is missing, maybe sequence error
                                FindRevV3 = FastqSequenceExtract.find('GCCAGCAGCCGCGGT')#V3 sequence in Forward direction
                                if FindRevV3 != -1:#Found it!
                                    pass
                                #found neither at this point, so get revComp
                                else:
                                    RCsequence = Seq(FastqSequenceExtract)#signal that it is a DNA sequence, not a string
                                    RCsequence = RCsequence.reverse_complement()#get the reverse complement of the genomic target
                                    FastqSequenceExtract = str(RCsequence)#turn 'Seq' back into string
                                    #reverse the quality scores
                                    FastqQualityExtractList = list(FastqQualityExtract)
                                    FastqQualityExtractList.reverse()
                                    FastqQualityExtract = ''.join(map(str, FastqQualityExtractList))
                            f.write('@' + FastqIDExtract.group(1).strip() + '\n')
                            f.write(FastqSequenceExtract + '\n')
                            f.write('+\n')
                            f.write(FastqQualityExtract + '\n')
                            ReadsWritten += 1
                        if LimitReadGet == 1:
                            if ReadsWritten >= ReadsToGet:
                                break
print('End of Program')
